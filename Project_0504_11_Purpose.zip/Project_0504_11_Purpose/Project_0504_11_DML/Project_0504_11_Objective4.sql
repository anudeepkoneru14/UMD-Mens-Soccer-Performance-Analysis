-- Objective 4: Is there a correlation between the spectator count and player performance? If yes which player performs the best
	-- when there are more spectators watching.
USE BUDT702_Project_0504_11

-- Calculating FWD players performance based on their G/A and match attendance
SELECT
    p.playerId AS 'Player Id',
    p.playerFirstName AS 'Player First Name',
    p.playerLastName AS 'Player Last Name',
	p.playerPosition AS 'Player Position',
    m.matchId AS 'Match Id',
    m.matchAttendance AS 'Match Attendance',
    pl.minutesPlayed AS 'Minutes Played',
	CAST(
		CASE
			WHEN PL.minutesPlayed > 0 THEN
			-- Formula Used = (((goal * 2 * (match Attendance/1000)) + (assist * 1.5 * (match Attendance/1000))) / minutes played * 90)
				(((pl.playerGoalCount * 2.0 * (m.matchAttendance / 1000)) + (pl.playerAssistCount * 1.5 * (m.matchAttendance / 1000))) / pl.minutesPlayed * 90) 
			ELSE
				0.0  -- default value when minutesPlayed is 0
		END AS DECIMAL(5,2)) AS 'Player Score Correlating With Audience Count' 
FROM
    [StatPad.Match] m
JOIN
    [StatPad.Play] pl ON m.matchId = pl.matchId
JOIN
    [StatPad.Player] p ON pl.playerId = p.playerId
WHERE
    p.playerPosition = 'FWD'  -- Specify the position as FWD
ORDER BY
    'Player Score Correlating With Audience Count'  DESC;


-- Observations 
-- 1) Yes it looks like there is a correlation between FWD player performance and match attendance. When the spectator count is above or equal to 2700
		-- the FWDs have less score
-- 2) Joshua Bolma and George Hunter have 3 non zero 'Player Score Correlating With Audience Count' scores, and Joshua Bolma has the highest score