-- Objective 2: Analyze the relationship between different match statistics, such as shots on target, fouls, and goals scored, for both home and away teams

USE BUDT702_Project_0504_11
SELECT
COALESCE(m.matchId, 'All Matches') AS 'Match Id',
COALESCE(p.teamIdFirst, 'All Teams') AS 'Away Team',
COALESCE(p.teamIdSecond, 'All Teams') AS 'Home Team',
COALESCE(SUM(ms.matchHomeTeamShotsOnTarget), 0) AS 'Home Shots on Target',
COALESCE(SUM(ms.matchAwayTeamShotsOnTarget), 0) AS 'Away Shots on Target',
COALESCE(SUM(ms.matchHomeTeamFouls), 0) AS 'Home Fouls',
COALESCE(SUM(ms.matchAwayTeamFouls), 0) AS 'Away Fouls',
COALESCE(SUM(ms.matchGoalsScored), 0) AS 'Total Goals Scored'
FROM
[StatPad.Match] m
LEFT JOIN
[StatPad.Participate] p ON m.matchId = p.matchId
LEFT JOIN
[StatPad.MatchStats] ms ON m.matchId = ms.matchId
GROUP BY CUBE (m.matchId, p.teamIdFirst, p.teamIdSecond)
ORDER BY [Match Id], [Home Team], [Away Team];

