-- Objective 3: What is the win/loss statistics for Maryland playing Home and Away and how much does attendance affect team performance?

USE BUDT702_Project_0504_11

SELECT 
    t.teamId AS 'Team Id',
    t.teamName AS 'Opposition Team Name',
    SUM(CASE 
            WHEN p.teamIdFirst = t.teamId AND p.homeTeamScore > p.awayTeamScore THEN 1
            WHEN p.teamIdSecond = t.teamId AND p.awayTeamScore > p.homeTeamScore THEN 1
            ELSE 0 
        END) AS 'Maryland Win',
    SUM(CASE 
            WHEN p.teamIdFirst = t.teamId AND p.homeTeamScore < p.awayTeamScore THEN 1
            WHEN p.teamIdSecond = t.teamId AND p.awayTeamScore < p.homeTeamScore THEN 1
            ELSE 0 
        END) AS 'Maryland Loss',
    COUNT(CASE 
            WHEN p.teamIdFirst = t.teamId THEN 1
            WHEN p.teamIdSecond = t.teamId THEN 1
            ELSE NULL 
        END) AS 'Total Matches',
    AVG(m.matchAttendance) AS 'Average Attendance',
    ROUND((SUM(CASE 
                WHEN p.teamIdFirst = t.teamId AND p.homeTeamScore > p.awayTeamScore THEN 1
                WHEN p.teamIdSecond = t.teamId AND p.awayTeamScore > p.homeTeamScore THEN 1
                ELSE 0 
            END) / CAST(COUNT(CASE 
                                WHEN p.teamIdFirst = t.teamId THEN 1
                                WHEN p.teamIdSecond = t.teamId THEN 1
                                ELSE NULL 
                            END) AS FLOAT)) * 100, 2) AS 'Win Percentage',
    CASE 
        WHEN t.teamId = 'T0001' THEN 1
        ELSE 0 
    END AS 'Maryland Home Game Flag'
FROM 
    [StatPad.Team] t
LEFT JOIN 
    [StatPad.Participate] p ON t.teamId = p.teamIdFirst OR t.teamId = p.teamIdSecond
LEFT JOIN 
    [StatPad.Match] m ON m.matchId = p.matchId
WHERE 
    t.teamId != 'T0001'
GROUP BY 
    t.teamId, t.teamName
ORDER BY 
    'Win Percentage' DESC;


-- We are also capturing the Average attendance on game day so that we can derive if the number of viewers affect our teams performance.

-- Observation: 
-- 1)We can see that Maryland Terrapins have won all their away games, but during the home games, we have won the matches when
		--average attendance has been between 1000 to 2000, whereas games where the average attendance goes above 2500, we have either drew or lost.

--Our assumption is that the extra viewers coming into the games are away fans and that factor plays a part in the game result for Maryland Terrapins
