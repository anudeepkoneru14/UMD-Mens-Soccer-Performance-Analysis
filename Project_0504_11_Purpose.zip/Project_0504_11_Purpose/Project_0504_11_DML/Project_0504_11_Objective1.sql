-- Objective 1 : Is there a correlation between goals, assists and fouls with player position?

USE BUDT702_Project_0504_11
DROP VIEW IF EXISTS PlayerStats;

-- Create a view named PlayerStats 
CREATE VIEW PlayerStats AS
SELECT 
    p.playerPosition,
    AVG(p.playerGoalsScored) OVER (PARTITION BY p.playerPosition) AS avgGoals,
    AVG(p.playerAssists) OVER (PARTITION BY p.playerPosition) AS avgAssists,
    AVG(p.playerYellowCardCount + p.playerRedCard) OVER (PARTITION BY p.playerPosition) AS avgFouls
FROM 
    [StatPad.Player] p;

-- Select and aggregate the data from the PlayerStats view based on player position
GO
SELECT ps.playerPosition AS 'Player Position', 
	SUM(ps.avgGoals) AS 'Average Goals', 
	SUM(ps.avgAssists) AS 'Average Assists', 
	SUM(ps.avgFouls) AS 'Average Fouls' FROM PlayerStats ps
WHERE ps.playerPosition IN ('GK', 'DEF', 'MID', 'FWD')
GROUP BY ps.playerPosition


-- We have created a view using window function to calculate average goals, average assists, and average fouls 
	-- for all Maryland Terrapin PLayers partitioned by the player position.

-- Observation: 
-- 1)We can see that goals, assists, and fouls are directly correlated to player positions and
		-- we see that Forwards contribute to most goals, Midfielders contribute to most assists,
		-- and most fouls are committed by the Defenders and Goalkeepers.
