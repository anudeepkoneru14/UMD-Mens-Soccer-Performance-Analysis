-- SQL DROP TABLE Code

USE BUDT702_Project_0504_11


DROP TABLE IF EXISTS [StatPad.Participate]; -- drops StatPad.Participate Table if it already exists in the database
DROP TABLE IF EXISTS [StatPad.Play]; -- drops StatPad.Play Table if it already exists in the database
DROP TABLE IF EXISTS [StatPad.MatchStats]; -- drops StatPad.MatchStats Table if it already exists in the database
DROP TABLE IF EXISTS [StatPad.Match]; -- drops StatPad.Match Table if it already exists in the database
DROP TABLE IF EXISTS [StatPad.Player]; -- drops StatPad.Player Table if it already exists in the database
DROP TABLE IF EXISTS [StatPad.Team]; -- drops StatPad.Team Table if it already exists in the database
DROP TABLE IF EXISTS [StatPad.Stadium]; -- drops StatPad.Stadium Table if it already exists in the database
