-- SQL CREATE TABLE Code

USE BUDT702_Project_0504_11

CREATE TABLE [StatPad.Stadium] ( -- creates a table name called Stadium
	stadiumId CHAR(5) NOT NULL,
	stadiumName VARCHAR(40),
	stadiumCapacity INT,
	stadiumLocation VARCHAR(40), 
	stadiumHomeTeam VARCHAR(40), 
	stadiumStreetAddress VARCHAR(40), 
	stadiumCity VARCHAR(20), 
	stadiumState VARCHAR(20), 
	stadiumZip CHAR(10),
	CONSTRAINT pk_Stadium_stadiumId PRIMARY KEY (stadiumId)) -- assigning primary key


CREATE TABLE [StatPad.Team] ( -- creates a table name called Team
	teamId CHAR(5) NOT NULL,
	teamCollegeName VARCHAR(40), 
	teamCoachName VARCHAR(40), 
	teamName VARCHAR(40), 
	teamYearEstablished INT, 
	stadiumId CHAR(5) NOT NULL,
	CONSTRAINT pk_Team_teamId PRIMARY KEY (teamId), -- assigning primary key
	CONSTRAINT fk_Team_stadiumId FOREIGN KEY (stadiumId)
		REFERENCES [StatPad.Stadium] (stadiumId)
		ON DELETE NO ACTION ON UPDATE NO ACTION)


CREATE TABLE [StatPad.Player] ( -- creates a table name called Player
	playerId CHAR(5) NOT NULL,
	playerFirstName VARCHAR(20), 
	playerLastName VARCHAR(20), 
	playerHeight FLOAT, 
	playerWeight FLOAT, 
	playerPosition VARCHAR(10), 
	playerJerseyNumber INT, 
	playerGoalsScored INT, 
	playerAssists INT, 
	playerYellowCardCount INT, 
	playerRedCard INT, 
	playerSaves INT, 
	teamId CHAR(5), 
	playerIdCaptain CHAR(5),
	CONSTRAINT pk_Player_playerId PRIMARY KEY (playerId), -- assigning primary key
	CONSTRAINT fk_Player_teamId FOREIGN KEY (teamId)
		REFERENCES [StatPad.Team] (teamId)
		ON DELETE CASCADE ON UPDATE CASCADE,
	CONSTRAINT fk_Player_playerIdCaptain FOREIGN KEY (playerIdCaptain)
		REFERENCES [StatPad.Player] (playerId)
		ON DELETE NO ACTION ON UPDATE NO ACTION)


CREATE TABLE [StatPad.Match] ( -- creates a table name called Match
	matchId CHAR(5) NOT NULL, 
	matchTimeStamp DATETIME, 
	matchRefreeName VARCHAR(40), 
	matchAssistantRefreeName VARCHAR(40), 
	matchHomeSubstitution INT, 
	matchAwaySubstitution INT, 
	matchAttendance INT, 
	stadiumId CHAR(5) NOT NULL,
	CONSTRAINT pk_Match_matchId PRIMARY KEY (matchId), -- assigning primary key
	CONSTRAINT fk_Match_stadiumId FOREIGN KEY (stadiumId)
		REFERENCES [StatPad.Stadium] (stadiumId)
		ON DELETE CASCADE ON UPDATE CASCADE)


CREATE TABLE [StatPad.MatchStats] ( -- creates a table name called MatchStats
	matchId CHAR(5) NOT NULL, 
	matchName VARCHAR(50) NOT NULL, 
	matchHomeTeamShotsOnTarget INT, 
	matchAwayTeamShotsOnTarget INT, 
	matchHomeTeamFouls INT, 
	matchAwayTeamFouls INT, 
	matchGoalsScored INT, 
	matchAssists INT,
	CONSTRAINT pk_MatchStats_matchId PRIMARY KEY (matchId), -- assigning primary key
	CONSTRAINT fk_MatchStats_matchId FOREIGN KEY (matchId)
		REFERENCES [StatPad.Match] (matchId)
		ON DELETE CASCADE ON UPDATE CASCADE)


CREATE TABLE [StatPad.Play] ( -- creates a table name called Play
	playerId CHAR(5) NOT NULL, 
	matchId CHAR(5) NOT NULL, 
	minutesPlayed INT,
	playerGoalCount INT,
	playerAssistCount INT,
	CONSTRAINT pk_MatchStats_playerId_matchId PRIMARY KEY (playerId, matchId), -- assigning primary key
	CONSTRAINT fk_Play_playerId FOREIGN KEY (playerId)
		REFERENCES [StatPad.Player] (playerId)
		ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT fk_Play_matchId FOREIGN KEY (matchId)
		REFERENCES [StatPad.Match] (matchId)
		ON DELETE CASCADE ON UPDATE CASCADE)


CREATE TABLE [StatPad.Participate] ( -- creates a table name called Participate
	teamIdFirst CHAR(5) NOT NULL,
	teamIdSecond CHAR(5) NOT NULL,
	matchId CHAR(5) NOT NULL, 
	homeTeamScore INT, 
	awayTeamScore INT,
	CONSTRAINT pk_Participate_teamIdFirst_teamIdSecond_matchId PRIMARY KEY (teamIdFirst, teamIdSecond, matchId), -- assigning primary key
	CONSTRAINT fk_Participate_teamIdFirst FOREIGN KEY (teamIdFirst)
		REFERENCES [StatPad.Team] (teamId)
		ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT fk_Participate_teamIdSecond FOREIGN KEY (teamIdSecond)
		REFERENCES [StatPad.Team] (teamId)
		ON DELETE NO ACTION ON UPDATE NO ACTION,
	CONSTRAINT fk_Participate_matchId FOREIGN KEY (matchId)
		REFERENCES [StatPad.Match] (matchId)
		ON DELETE CASCADE ON UPDATE CASCADE)